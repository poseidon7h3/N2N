<?php
 $conn=new mysqli('localhost','root','','n2n');
if($conn->connect_error)
{
	die("Connection Error".$conn->connect_error);
}
if(!isset($_POST['sbt']))
{
	die("Security Error");
}
function NewUser() 
 {  
	 
	$email = $_POST['email'];
	$password = $_POST['pass'];
	$cnfrm = $_POST['cnfrm'];
	$query = "INSERT INTO user (email,pass,cnfrm) VALUES ('$email','$password,$cnfrm')"; 
	$data = mysql_query ($query)or die(mysql_error());
	if($data) 
	{ 
		echo "YOUR REGISTRATION IS COMPLETED..."; 
	}		
} 
		function SignUp() 
		{ 
			if(!empty($_POST['email'])) //checking the 'user' name which is from Sign-Up.html, is it empty or have some text 
			{ 
				$query = mysql_query("SELECT * FROM user WHERE email = '$_POST[email]' AND pass = '$_POST[pass]'") or die(mysql_error());
				if(!$row = mysql_fetch_array($query) or die(mysql_error())) 
				{ 
					newuser(); 
				} 
				else 
				{ 
					echo "SORRY...YOU ARE ALREADY REGISTERED USER..."; 
				} 
			} 
		} 
		if(isset($_POST['submit'])) 
		{ 
			SignUp();
		} 
?>

